module.exports = require('./v2');
module.exports.v2 = require('./v2');
module.exports.canary = require('./canary');
module.exports.v3 = require('./canary');
module.exports.shared = require('./shared');
