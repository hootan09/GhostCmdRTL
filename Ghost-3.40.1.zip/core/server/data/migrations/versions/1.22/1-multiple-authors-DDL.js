const {addTable} = require('../../utils');
module.exports = addTable('posts_authors');
