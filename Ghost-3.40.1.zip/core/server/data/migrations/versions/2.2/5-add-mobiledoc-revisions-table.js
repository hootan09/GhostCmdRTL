const {addTable} = require('../../utils');
module.exports = addTable('mobiledoc_revisions');
