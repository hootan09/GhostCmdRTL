const {addTable} = require('../../utils');
module.exports = addTable('webhooks');
