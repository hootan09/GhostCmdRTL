module.exports.up = module.exports.down = () => Promise.resolve();
