module.exports = {
    get settings() {
        return require('./settings');
    },

    get validation() {
        return require('./validation');
    }
};
